from a4task1 import trapint

# data from problem
e = [0.02,0.05,0.10,0.15,0.20,0.25] 
s = [40.0,37.5,43.0,53.0,60.0,55.0]

A = trapint(e,s) # function in part 1
print(A)
