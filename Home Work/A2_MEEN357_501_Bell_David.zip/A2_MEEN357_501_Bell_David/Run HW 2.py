import A2 as HW 

#HW.A2_task1()
#HW.A2_task2()
#HW.A2_task3()
#HW.A2_task4()
HW.A2_task5()
